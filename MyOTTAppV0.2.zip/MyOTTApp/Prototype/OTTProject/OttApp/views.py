from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from .forms import MyMovieForm
from OttApp.models import MyMovie

def index(request):
    #myMoviesResponse = {}
    MyMovies = MyMovie.objects.all()
    #for movie in MyMovies:
    #    print(movie)
    #    myMoviesResponse[movie.MovieName] = {'movie':movie.MovieName,'genre':movie.Genre,'document':movie.document,'uploadTime':movie.uploaded_at}
    #print(myMoviesResponse)
    return render(request, 'OttApp/index.html', {'movies':MyMovies})


def model_form_upload(request):
    if request.method == 'POST':
        form = MyMovieForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('OttApp:index')
    else:
        form = MyMovieForm()
    return render(request, 'OttApp/model_form_upload.html', {
        'form': form
    })


def edit_movieform(request,movie_id):
    movie = MyMovie.objects.get(id=movie_id)
    movieName = movie.MovieName
    if request.method != 'POST':
        form = MyMovieForm(instance=movie)
    else:
        form = MyMovieForm(instance=movie, data=request.POST)
        if form.is_valid():
            form.save()
            return redirect('OttApp:index')
    context = {'movie': movie, 'movieName': movieName, 'form': form}
    return render(request, 'OttApp/edit_movieform.html', context)

def delete_movie(request,movie_id):
    movie = MyMovie.objects.get(id=movie_id)
    movie.delete()
    print(movie," is deleted")
    return redirect('OttApp:index')
