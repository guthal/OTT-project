from django.contrib import admin

from .models import MyMovie

admin.site.register(MyMovie)