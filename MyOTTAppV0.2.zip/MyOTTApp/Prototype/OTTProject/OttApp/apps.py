from django.apps import AppConfig


class OttappConfig(AppConfig):
    name = 'OttApp'
