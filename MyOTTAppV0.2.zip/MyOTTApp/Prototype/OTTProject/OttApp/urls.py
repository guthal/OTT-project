from django.urls import path
from . import views

app_name = 'OttApp'

urlpatterns = [
    path('', views.index, name = 'index'),
    path('model_form_upload/', views.model_form_upload, name = 'model_form_upload'),
    path('edit_movieform/<int:movie_id>/', views.edit_movieform, name='edit_movieform'),
    path('delete_movie/<int:movie_id>/', views.delete_movie, name='delete_movie')
]

