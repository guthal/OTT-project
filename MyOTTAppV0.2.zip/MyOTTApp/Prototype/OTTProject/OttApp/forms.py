from django import forms
from .models import MyMovie

class MyMovieForm(forms.ModelForm):
    class Meta:
        model = MyMovie
        fields = ('MovieName', 'Genre', 'document', )