from django.db import models


class FMUser(models.Model):
    Name = models.CharField(max_length=25)
    Entity_Type = models.CharField(max_length=5)
    CompanyRegNo = models.CharField(max_length=15, blank=True)
    Cert_Reg_Name = models.CharField(max_length=25, blank=True)
    Cert_Reg_Path = models.FileField(blank=True)
    AADHAR_No = models.CharField(max_length=20)
    PAN_No = models.CharField(max_length=15)
    Address_company = models.CharField(max_length=50)
    Bank_Acc_No = models.CharField(max_length=20)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.Name