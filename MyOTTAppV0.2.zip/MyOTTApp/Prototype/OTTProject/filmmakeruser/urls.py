from django.urls import path
from . import views

app_name = 'filmmakeruser'

urlpatterns = [
    path('', views.filmmakerpage, name = 'filmmakerpage'),
    path('fm_form_upload/', views.fm_form_upload, name = 'fm_form_upload'),
    path('edit_filmmakerform/<int:fm_id>/', views.edit_filmmakerform, name='edit_filmmakerform'),
    
]