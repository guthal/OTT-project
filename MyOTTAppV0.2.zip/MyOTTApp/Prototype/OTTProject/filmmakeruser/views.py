from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from .forms import FMUserForms
from filmmakeruser.models import FMUser

def filmmakerpage(request):
    FMUsersList = FMUser.objects.all()
    return render(request, 'filmmakeruser/index.html', {'FMUsersList':FMUsersList})


def fm_form_upload(request):
    if request.method == 'POST':
        form = FMUserForms(request.POST, request.FILES)
        if form.is_valid():
            form.save()
        return redirect('filmmakeruser:filmmakerpage')
    else:
        form = FMUserForms()
    return render(request, 'filmmakeruser/fm_form_upload.html', {
        'form': form
    })

def edit_filmmakerform(request,fm_id):
    fm_user = FMUser.objects.get(id=fm_id)
    user = fm_user.Name
    if request.method != 'POST':
        form = FMUserForms(instance=fm_user)
    else:
        form = FMUserForms(instance=fm_user, data=request.POST)
        if form.is_valid():
            form.save()
            return redirect('filmmakeruser:filmmakerpage')
    context = {'fm_user': fm_user, 'movieName': user, 'form': form}
    return render(request, 'filmmakeruser/fm_form_edit.html', context)