from django.apps import AppConfig


class FilmmakeruserConfig(AppConfig):
    name = 'filmmakeruser'
