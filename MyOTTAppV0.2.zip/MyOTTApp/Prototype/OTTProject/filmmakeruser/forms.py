from django import forms
from .models import FMUser

class FMUserForms(forms.ModelForm):
    class Meta:
        model = FMUser
        fields = ('Name', 'Entity_Type', 'CompanyRegNo','Cert_Reg_Name','Cert_Reg_Path','AADHAR_No','PAN_No', 'Address_company','Bank_Acc_No')