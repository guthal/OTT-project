//jshint esversion:6

const express = require("express");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const mongoose = require('mongoose');
const {v4, stringify} =require('uuid');

const app = express();

app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));

mongoose.connect("mongodb://localhost:27017/contentUpload", {useNewUrlParser: true,useUnifiedTopology: true});

//creator info

const creatorSchema = {
    creatorId:{ type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    creator: { type: String, required: true, unique: true },
    address:String,
    office:String,
    city:String,
    state:String,
    zip:Number,
    date:Date
  };

  
  const brSchema={
      creatorId:String,
      price:{
          buy:{ 
              hd:Number,
            sd:Number
        },
        rent:{
            hd:Number,
            sd:Number
        }
    },
    title:String,
    description:String,
    date:Date,
    genre:String
}

//schemas constructors
const BR=mongoose.model("BR",brSchema);
const Creator = mongoose.model("Creator", creatorSchema);

app.get("/",(req,res)=>{
    res.send("landing page")
})

app.get("/upload",(req,res)=>{
    Creator.find({}, function(err, creators){
        res.render("upload", {
            creators: creators
        });
    });
});

//weekly streams schema

const weeklySchema={
    creatorId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Creator'
    },
    price:Number,
    title:String,
    description:String,
    weeks:Number,
    genre:String,
    start:Date,
    end:String
}

const Weekly = mongoose.model("Weekly",weeklySchema);
app.param('creatorId', function(req, res, next, name) {

    // check if the user with that name exists
    // do some validations
    // add -dude to the name
    // save name to the request
    req.creatorId = req.body.creatorId;

    next();
});

app.get("/upload/week/:creatorId",(req,res)=>{
    console.log(req.params.creatorId);
    res.render("weekly");
})


app.post("/upload/week/:creatorId",(req,res)=>{
    console.log(req.params.creatorId+" this is the creator Id");
    
    const d = new Date();
    d.setDate(d.getDate() + req.body.weeks*7);
    const endDate=d.toString
    console.log(d+" value of d");
    console.log(Date(endDate.toString())+" value of end date");
    console.log(Date.now()+" Time of today");
    
    const weekly= new Weekly({
        creatorId:Creator._id,
        price:req.body.price,
        title:req.body.title,
        description:req.body.description,
        weeks:req.body.weeks,
        genre:req.body.genre,
        start:Date.now(),
        end:endDate.toString()
    })
    weekly.save(function(err){
        if (!err){
            res.redirect("/");
        }
      });
})

app.get("/upload/br/:creatorId",(req,res)=>{
    res.send("BUY/RENT");
})

app.post("/upload/br/:creatorId",(req,res)=>{
    const br= new BR({
        creatorId:req.body.creatorId,
    price:{
        buy:{ 
            hd:req.body.bhd,
            sd:req.body.bsd
           },
        rent:{
            hd:req.body.rhd,
            sd:req.body.rsd
        }},
    title:req.body.title,
    description:req.body.description,
    date:Date.now(),
    genre:req.body.genre
    })
    br.save(function(err){
        if (!err){
            res.redirect("/");
        }
      });
})

app.get("/register", function(req, res){
    res.render("fm-register")
});

app.post("/register",(req,res)=>{
    const creator = new Creator({
     creatorId:v4(),
     email: req.body.email,
     creator: req.body.creator,
     address:req.body.address,
     office:req.body.office || null,
     city:req.body.city,
     state:req.body.state,
     zip:req.body.zip,
     date:Date.now()
    })
    creator.save(function(err){
        if (!err){
            res.redirect("/");
        }
      });
})

app.listen(3000, function() {
  console.log("Server started on port 3000");
});